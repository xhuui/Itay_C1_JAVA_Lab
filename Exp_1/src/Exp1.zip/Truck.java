public class Truck extends Vehicle{
    public Truck(Integer GPK, String make, String color, Integer tank_size) {
        super(GPK, make, color, tank_size);
        num_of_tires = 8;
    }
}
