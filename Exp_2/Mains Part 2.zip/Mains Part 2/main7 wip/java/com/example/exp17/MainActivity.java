package com.example.exp17;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.MediaMetadataRetriever;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.URLUtil;

import java.io.IOException;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private TextView title, artist, album;
    private EditText url;
    private ImageView imageView;
    private Button button;
    private MediaPlayer mediaPlayer;
    private boolean isPlaying = false;
    private boolean isPlayingOnNewUrl = false;  // To track if the media player is playing on a new URL
    private String currentUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        title = findViewById(R.id.title_title);
        artist = findViewById(R.id.artist_title);
        album = findViewById(R.id.album_title);
        url = findViewById(R.id.editTextText);
        imageView = findViewById(R.id.imageView);
        button = findViewById(R.id.button);

        // Initialize MediaPlayer
        mediaPlayer = new MediaPlayer();

        // Allow network access on the main thread (for simplicity in this example)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handlePlayPause();
            }
        });
    }

    private void handlePlayPause() {
        String urlInput = url.getText().toString().trim();

        if (TextUtils.isEmpty(urlInput) || !URLUtil.isHttpsUrl(urlInput)) {
            Toast.makeText(MainActivity.this, "Wrong URL", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!currentUrl.equals(urlInput)) {
            // Stop and reset the MediaPlayer if URL has changed
            if (isPlaying) {
                mediaPlayer.stop();
                mediaPlayer.reset();
                isPlaying = false;
                button.setText("Play");
            }

            currentUrl = urlInput;
            isPlayingOnNewUrl = true;

            try {
                mediaPlayer.setDataSource(currentUrl);
                mediaPlayer.prepare();
                mediaPlayer.start();
                isPlaying = true;
                button.setText("Pause");

                // Retrieve and display metadata
                updateMetadata(currentUrl);
            } catch (IOException e) {
                Log.e("MainActivity", "Error in MediaPlayer", e);
                Toast.makeText(MainActivity.this, "Error playing media " + urlInput, Toast.LENGTH_SHORT).show();
            }
        } else {
            // Toggle play/pause
            if (isPlaying) {
                mediaPlayer.pause();
                button.setText("Play");
            } else {
                mediaPlayer.start();
                button.setText("Pause");
            }
            isPlaying = !isPlaying;
        }
    }

    private void updateMetadata(String url) throws IOException {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(url, new HashMap<>());
            String titleText = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artistText = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String albumText = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            byte[] albumArt = retriever.getEmbeddedPicture();

            runOnUiThread(() -> {
                if (titleText != null) {
                    title.setText("Title: " + titleText);
                }
                if (artistText != null) {
                    artist.setText("Artist: " + artistText);
                }
                if (albumText != null) {
                    album.setText("Album: " + albumText);
                }
                if (albumArt != null) {
                    Bitmap bitmap = BitmapFactory.decodeByteArray(albumArt, 0, albumArt.length);
                    imageView.setImageBitmap(bitmap);
                } else {
                    imageView.setImageResource(R.drawable.ic_launcher_foreground); // Default image
                }
            });

        } catch (Exception e) {
            Log.e("MainActivity", "Error retrieving metadata", e);
        } finally {
            retriever.release();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            if (isPlaying) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
