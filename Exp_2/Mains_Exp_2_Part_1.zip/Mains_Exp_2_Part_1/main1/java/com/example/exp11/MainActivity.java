package com.example.exp11;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button enter_button, clear_button;
    private RadioGroup radioGroup;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.InputText);
        enter_button = findViewById(R.id.enter_button);
        clear_button = findViewById(R.id.clear_button);
        radioGroup = findViewById(R.id.Colors);
        enter_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setText(editText.getText());
            }
        });
        clear_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setText(R.string.default_text);
                radioGroup.check(R.id.Red);
                textView.setTextColor(Color.BLACK);
            }
        });
        radioGroup.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.Red) {
                textView.setTextColor(Color.RED);
            } else if (i == R.id.Green) {
                textView.setTextColor(Color.GREEN);
            } else if (i == R.id.Blue) {
                textView.setTextColor(Color.BLUE);
            }
        });

    }

}