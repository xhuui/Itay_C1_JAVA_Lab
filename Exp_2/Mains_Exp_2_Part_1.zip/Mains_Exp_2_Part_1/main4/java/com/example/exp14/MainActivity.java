package com.example.exp14;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private Bitmap bitmap1,bitmap2;
    private Boolean state;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        state = Boolean.FALSE;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            bitmap1 = drawableFromUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Googleplex_HQ_%28cropped%29.jpg/1200px-Googleplex_HQ_%28cropped%29.jpg");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            bitmap2 = drawableFromUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/0/0a/Google_page_brin.jpg/1024px-Google_page_brin.jpg");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        imageView = findViewById(R.id.imageView);
        imageView.setImageBitmap(bitmap1);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (state == Boolean.FALSE) {
                    imageView.setImageBitmap(bitmap2);
                }
                else {
                    imageView.setImageBitmap(bitmap1);
                }
                state = !state;

            }
        });
    }
    Bitmap drawableFromUrl(String url) throws java.net.MalformedURLException,    java.io.IOException {
        Bitmap x;
        HttpURLConnection connection = (HttpURLConnection)new URL(url) .openConnection();
        connection.setRequestProperty("User-agent","Mozilla/4.0");
        connection.connect();
        InputStream input = connection.getInputStream();
        x = BitmapFactory.decodeStream(input);
        return x;
    }

}