package com.example.exp15;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private TextView textView;
    private ImageButton plus_but, minus_but;
    private Button finishButton;
    private Integer number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        // Get the data from the intent
        String receivedText = getIntent().getStringExtra("extra_data");
        number = Integer.parseInt(receivedText);
        textView = findViewById(R.id.textView);
        plus_but = findViewById(R.id.plusButton);
        minus_but = findViewById(R.id.minusButton);
        finishButton = findViewById(R.id.finishButton);
        textView.setText(getString(R.string.top_text_2) + " " +receivedText);
        plus_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number ++;
                textView.setText(getString(R.string.top_text_2) + " " + number);
            }
        });
        minus_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number --;
                textView.setText(getString(R.string.top_text_2) + " " + number);
            }
        });
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("result_data", number.toString());
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });

    }
}