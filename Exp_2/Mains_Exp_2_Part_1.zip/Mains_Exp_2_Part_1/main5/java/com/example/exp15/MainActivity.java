package com.example.exp15;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.BoringLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText editText;
    private Button button;
    private TextView textView;
    private String result,last_value;
    private static final int REQUEST_CODE = 1;
    private Boolean first_time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editTextText);
        button = findViewById(R.id.calculateButton);
        textView = findViewById(R.id.bottomText);
        first_time = Boolean.TRUE;
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = editText.getText().toString();
                if (!text.equals("") && (first_time == Boolean.TRUE || !last_value.equals(text))){
                    first_time = Boolean.FALSE;
                    last_value = text;
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    intent.putExtra("extra_data", text);
                    startActivityForResult(intent, REQUEST_CODE);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                result = data.getStringExtra("result_data");
                textView.setText(getString(R.string.bottom_text) + ": " + result);
            }
        }
    }
}