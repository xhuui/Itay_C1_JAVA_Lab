public class Motorcycle extends Vehicle{
    public Motorcycle(Integer GPK, String make, String color, Integer tank_size) {
        super(GPK, make, color, tank_size);
        num_of_tires = 2;
    }
}
