public class DeathStar extends SpaceShip {
    public DeathStar(Integer GPK, String make, String color, Integer tank_size) {
        super(GPK, make, color, tank_size);
    }
}
