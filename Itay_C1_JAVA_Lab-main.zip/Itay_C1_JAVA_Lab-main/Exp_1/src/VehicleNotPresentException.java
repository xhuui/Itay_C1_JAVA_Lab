public class VehicleNotPresentException extends RuntimeException{
    public VehicleNotPresentException(){
        super();
    }
    public VehicleNotPresentException(String str){
        super(str);
    }
}
